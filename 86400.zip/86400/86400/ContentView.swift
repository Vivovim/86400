//
//  ContentView.swift
//  86400
//
//  Created by Christopher Huffaker on 10/17/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            
            Link("My Digital Chaos",
                  destination: URL(string: "https://xyzzy42.me/links")!)
            
                .onAppear() {
                    
                    
                   
                   

                }
            
            
            
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
