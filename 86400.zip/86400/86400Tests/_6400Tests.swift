//
//  _6400Tests.swift
//  86400Tests
//
//  Created by Christopher Huffaker on 10/17/24.
//

import Testing
@testable import _6400

struct _6400Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
